//
//  ViewController.h
//  calculator
//
//  Created by Student on 28/11/16.
//  Copyright (c) 2016 Student. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITextField *tf1;

@property (weak, nonatomic) IBOutlet UITextField *tf2;

@property (weak, nonatomic) IBOutlet UISegmentedControl *segment;

- (IBAction)calculatebtn:(id)sender;
//@property int *num1,*num2,;

@property (weak, nonatomic) IBOutlet UITextField *anstf;

@end
