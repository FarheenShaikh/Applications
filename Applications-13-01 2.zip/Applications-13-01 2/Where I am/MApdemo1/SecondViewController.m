//
//  SecondViewController.m
//  MApdemo1
//
//  Created by student14 on 12/01/17.
//  Copyright © 2017 Student. All rights reserved.
//

#import "SecondViewController.h"

@interface SecondViewController ()
@property (strong, nonatomic) CLLocationManager *locationManager;

@end
@implementation SecondViewController
CLPlacemark *DestPlacemark;
MKRoute *routeDetails;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.mapview.delegate=self;
    
    if (!self.locationManager) {
        self.locationManager = [[CLLocationManager alloc] init];
    }
    [self.locationManager requestAlwaysAuthorization];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)searchtextfield:(UITextField *)sender {
    
    CLGeocoder *Geocoder = [[CLGeocoder alloc] init];
    [Geocoder geocodeAddressString:sender.text completionHandler:^(NSArray *placemarks, NSError *error) {
//        if (error) {
//            NSLog(@"%@", error);
//        }
//        else {
            DestPlacemark = [placemarks lastObject];
            float spanX = 1.00725;
            float spanY = 1.00725;
            MKCoordinateRegion region;
            region.center.latitude = DestPlacemark.location.coordinate.latitude;
            region.center.longitude =DestPlacemark.location.coordinate.longitude;
            region.span = MKCoordinateSpanMake(spanX, spanY);
            [self.mapview setRegion:region animated:YES];
            [self addAnnotation:DestPlacemark];
        //}
    }];
}
- (void)addAnnotation:(CLPlacemark *)placemark {
    
    MKPointAnnotation *point = [[MKPointAnnotation alloc] init];
    point.coordinate = CLLocationCoordinate2DMake(placemark.location.coordinate.latitude, placemark.location.coordinate.longitude);
    point.title =placemark.subLocality;
    
    //[placemark.addressDictionary objectForKey:@"Street"];
    point.subtitle =placemark.country;
    //[placemark.addressDictionary objectForKey:@"City"];
    [self.mapview addAnnotation:point];
}

- (IBAction)getroutebtn:(id)sender {
    
    MKDirectionsRequest *directionsRequest = [[MKDirectionsRequest alloc] init];
    MKPlacemark *placemark = [[MKPlacemark alloc] initWithPlacemark:DestPlacemark];
    MKPlacemark *placemarkS=[[MKPlacemark alloc]initWithPlacemark:_sourcePlacemark];
    
   // [directionsRequest setSource:[MKMapItem mapItemForCurrentLocation]];
    
    [directionsRequest setSource:[[MKMapItem alloc]initWithPlacemark:placemarkS]];
    [directionsRequest setDestination:[[MKMapItem alloc] initWithPlacemark:placemark]];
    directionsRequest.transportType = MKDirectionsTransportTypeAutomobile;
    MKDirections *directions = [[MKDirections alloc] initWithRequest:directionsRequest];
    [directions calculateDirectionsWithCompletionHandler:^(MKDirectionsResponse *response, NSError *error) {
        if (error) {
            NSLog(@"Error %@", error.description);
       } else {
      //  NSLog(@"%@",response);
            routeDetails = response.routes.lastObject;
            [self.mapview addOverlay:routeDetails.polyline];
            self.destinationlbl.text = [placemark.addressDictionary objectForKey:@"Street"];
            self.distancelbl.text = [NSString stringWithFormat:@"%0.1f Miles", routeDetails.distance/1609.344];
            self.transportlbl.text = [NSString stringWithFormat:@"%u" ,routeDetails.transportType];
            self.allSteps = @"";
            for (int i = 0; i < routeDetails.steps.count; i++) {
                MKRouteStep *step = [routeDetails.steps objectAtIndex:i];
                NSString *newStep = step.instructions;
                self.allSteps = [self.allSteps stringByAppendingString:newStep];
                self.allSteps = [self.allSteps stringByAppendingString:@"\n\n"];
                self.steps.text = self.allSteps;
            }
       }
        
    }];
    
    
    
}
-(MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id<MKAnnotation>)annotation
{
    if ([annotation isKindOfClass:[MKUserLocation class]])
        return nil;
    // Handle any custom annotations.
    if ([annotation isKindOfClass:[MKPointAnnotation class]]) {
        // Try to dequeue an existing pin view first.
        MKPinAnnotationView *pinView = (MKPinAnnotationView*)[self.mapview dequeueReusableAnnotationViewWithIdentifier:@"CustomPinAnnotationView"];
        if (!pinView)
        {
            // If an existing pin view was not available, create one.
            pinView = [[MKPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:@"CustomPinAnnotationView"];
            pinView.canShowCallout = YES;
        } else {
            pinView.annotation = annotation;
        }
        return pinView;
    }
    return nil;

}

-(MKOverlayRenderer *)mapView:(MKMapView *)mapView rendererForOverlay:(id<MKOverlay>)overlay {
    MKPolylineRenderer  * routeLineRenderer = [[MKPolylineRenderer alloc] initWithPolyline:routeDetails.polyline];
    routeLineRenderer.strokeColor = [UIColor redColor];
    routeLineRenderer.lineWidth = 5;
    return routeLineRenderer;
}

@end
