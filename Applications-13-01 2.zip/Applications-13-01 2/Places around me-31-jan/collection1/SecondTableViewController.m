//
//  SecondTableViewController.m
//  collection1
//
//  Created by Student on 10/01/17.
//  Copyright (c) 2017 Student. All rights reserved.
//

#import "SecondTableViewController.h"
#import "CustomTableViewCell.h"

@interface SecondTableViewController ()

@end

@implementation SecondTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _namearr=[[NSMutableArray alloc]init];
    _addarr=[[NSMutableArray alloc]init];
    
    [self.tableView registerNib:[UINib nibWithNibName:@"CustomTableViewCell" bundle:[NSBundle mainBundle]] forCellReuseIdentifier:@"cell"];
    
    NSURL *url=[NSURL URLWithString:[NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=18.5074,73.8077&radius=500&type=%@&key=AIzaSyDRKtZoGVsZeVd1nlEl0ZPbmOslfxWXUJA",_typestring]];
    
    NSMutableURLRequest *req=[NSMutableURLRequest requestWithURL:url];
    NSURLSessionConfiguration *conf=[NSURLSessionConfiguration defaultSessionConfiguration];
    
    NSURLSession *session=[NSURLSession sessionWithConfiguration:conf];
    
    
    
    NSURLSessionDataTask *task1=[session dataTaskWithRequest:req completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        
        
        NSDictionary *outerdic=[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        if ([_typestring isEqualToString:_typestring]) {
            
            NSArray *resultarr=[outerdic objectForKey:@"results"];
            for(NSDictionary *tempdic in resultarr)
            {
            NSString *name=[tempdic objectForKey:@"name"];
            NSString *add=[tempdic objectForKey:@"vicinity"];
                NSLog(@"%@  %@",name,add);
            [_namearr addObject:name];
            [_addarr addObject:add];
               //[self.tableView reloadData];
            }
            
            
            
            
        }
//        if ([_typestring isEqualToString:@"ATM"]) {
//            
//            
//        }
//        if ([_typestring isEqualToString:@"Hospital"]) {
//            
//        }
//        if ([_typestring isEqualToString:@"Hotel"]) {
//            
//        }
//        if ([_typestring isEqualToString:@"RailwaySation"]) {
//            
//        }
//        if ([_typestring isEqualToString:@"Busstop"]) {
//            
//        }

        [self.tableView reloadData];
        
    }];
    
    [task1 resume];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
//#warning Potentially incomplete method implementation.
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
//#warning Incomplete method implementation.
    // Return the number of rows in the section.
    return _namearr.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
     CustomTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    
    // Configure the cell...
    
    cell.namelbl.text=[_namearr objectAtIndex:indexPath.row];
    cell.addlbl.text=[_addarr objectAtIndex:indexPath.row];
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{

    return 100;
}


/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
