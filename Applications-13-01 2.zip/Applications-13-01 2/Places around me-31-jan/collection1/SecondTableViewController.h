//
//  SecondTableViewController.h
//  collection1
//
//  Created by Student on 10/01/17.
//  Copyright (c) 2017 Student. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SecondTableViewController : UITableViewController
@property(nonatomic,retain)NSString *typestring;
@property(nonatomic,retain)NSMutableArray *namearr,*addarr;
@end
