//
//  CollectionViewController.m
//  collection1
//
//  Created by Student on 28/12/16.
//  Copyright (c) 2016 Student. All rights reserved.
//

#import "CollectionViewController.h"
#import "CustomCollectionViewCell.h"
//#import "SecondTableViewController.h"
#import "SecondViewController.h"

@interface CollectionViewController ()

@end

@implementation CollectionViewController

static NSString * const reuseIdentifier = @"Cell";

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _imagearray=[[NSArray alloc]initWithObjects:@"Bank.png",@"atm.png",@"hospital.png",@"Hotel.png",@"gym.jpeg",@"busstop.png", nil];
    _namearray=[[NSArray alloc]initWithObjects:@"bank",@"ATM",@"Hospital",@"Hotel",@"Gym",@"Busstop", nil];
   _name1array=[[NSArray alloc]initWithObjects:@"bank",@"atm",@"hospital",@"restaurant",@"gym",@"", nil];
    
    [self.collectionView registerNib:[UINib nibWithNibName:@"CustomCollectionViewCell" bundle:[NSBundle mainBundle]]forCellWithReuseIdentifier:reuseIdentifier];
    

    // Register cell classes
  //  [self.collectionView registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:reuseIdentifier];
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
   // UITouch *t=[touches anyObject];
    
}

#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
    SecondViewController *svc=[segue destinationViewController];
   // UICollectionViewCell *c=(UICollectionViewCell *)sender;
    
    NSIndexPath *index=[[self.collectionView indexPathsForSelectedItems]lastObject];
    NSLog(@"%ld",(long)index.row);
   // NSIndexPath *index=[indexarr ]
    //NSIndexPath *indexpath=[self.collectionView indexPathForCell:c];
    //NSLog(@"%ld",(long)indexpath.row);
    svc.typestring=[_name1array objectAtIndex:index.row];

    //svc.typestring=

}


#pragma mark <UICollectionViewDataSource>

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 1;
}


- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return _imagearray.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
//    UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:reuseIdentifier forIndexPath:indexPath];
    CustomCollectionViewCell *cell=[collectionView dequeueReusableCellWithReuseIdentifier:reuseIdentifier forIndexPath:indexPath];
    
    // Configure the cell
    cell.imgview.image=[UIImage imageNamed:[_imagearray objectAtIndex:indexPath.row]];
    cell.label.text=[_namearray objectAtIndex:indexPath.row];
    cell.label.textColor=[UIColor redColor];

    
    
    return cell;
}

-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    [self performSegueWithIdentifier:@"fvctosvc" sender:self];
   

    
    
    
    
        
    
}

-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(50, 0, 0, 0);
    
}



#pragma mark <UICollectionViewDelegate>

/*
// Uncomment this method to specify if the specified item should be highlighted during tracking
- (BOOL)collectionView:(UICollectionView *)collectionView shouldHighlightItemAtIndexPath:(NSIndexPath *)indexPath {
	return YES;
}
*/

/*
// Uncomment this method to specify if the specified item should be selected
- (BOOL)collectionView:(UICollectionView *)collectionView shouldSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    return YES;
}
*/

/*
// Uncomment these methods to specify if an action menu should be displayed for the specified item, and react to actions performed on the item
- (BOOL)collectionView:(UICollectionView *)collectionView shouldShowMenuForItemAtIndexPath:(NSIndexPath *)indexPath {
	return NO;
}

- (BOOL)collectionView:(UICollectionView *)collectionView canPerformAction:(SEL)action forItemAtIndexPath:(NSIndexPath *)indexPath withSender:(id)sender {
	return NO;
}

- (void)collectionView:(UICollectionView *)collectionView performAction:(SEL)action forItemAtIndexPath:(NSIndexPath *)indexPath withSender:(id)sender {
	
}
*/

@end
