//
//  SecondViewController.m
//  collection1
//
//  Created by student14 on 31/01/17.
//  Copyright © 2017 Student. All rights reserved.
//

#import "SecondViewController.h"
#import "CustomTableViewCell.h"

@interface SecondViewController ()

@end
CLPlacemark *description;

@implementation SecondViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
//    _manager=[[CLLocationManager alloc]init];
//    _manager.delegate=self;
//    _manager.desiredAccuracy=kCLLocationAccuracyBest;
//    [_manager startUpdatingLocation];
//    
    _geocoder=[[CLGeocoder alloc]init];
    
    [self.manager requestAlwaysAuthorization];
    
    _namearr=[[NSMutableArray alloc]init];
    _addarr=[[NSMutableArray alloc]init];
    
    [self.tableview registerNib:[UINib nibWithNibName:@"CustomTableViewCell" bundle:[NSBundle mainBundle]] forCellReuseIdentifier:@"cell"];
    
    NSURL *url=[NSURL URLWithString:[NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=18.5074,73.8077&radius=100000&type=%@&key=AIzaSyDRKtZoGVsZeVd1nlEl0ZPbmOslfxWXUJA",_typestring]];
    
    NSMutableURLRequest *req=[NSMutableURLRequest requestWithURL:url];
    NSURLSessionConfiguration *conf=[NSURLSessionConfiguration defaultSessionConfiguration];
    
    NSURLSession *session=[NSURLSession sessionWithConfiguration:conf];
    
    
    
    NSURLSessionDataTask *task1=[session dataTaskWithRequest:req completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        
        
        NSDictionary *outerdic=[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        //if ([_typestring isEqualToString:_typestring]) {
            
            NSArray *resultarr=[outerdic objectForKey:@"results"];
            for(NSDictionary *tempdic in resultarr)
            {
                NSString *name=[tempdic objectForKey:@"name"];
                NSString *add=[tempdic objectForKey:@"vicinity"];
                NSLog(@"%@  %@",name,add);
                [_namearr addObject:name];
                [_addarr addObject:add];
                
                NSDictionary *geometry=[tempdic objectForKey:@"geometry"];
                NSDictionary *locat=[geometry objectForKey:@"location"];
                NSNumber *lat=[locat objectForKey:@"lat"];
                NSNumber *longg=[locat objectForKey:@"lng"];
                NSLog(@"%@  %@ ",lat,longg);
                
                
                CLLocation *location = [[CLLocation alloc] initWithLatitude:[lat doubleValue] longitude:[longg doubleValue]];
                
                CLLocationCoordinate2D location2D;
                location2D.latitude=[lat doubleValue];
                location2D.longitude=[longg doubleValue];
                
                
                [_geocoder reverseGeocodeLocation:location completionHandler:^(NSArray *placemarks, NSError *error)
                 {
                     description=[placemarks objectAtIndex:0];
                     // NSLog(@"%@",description);
                     
                     MKPointAnnotation *point1=[[MKPointAnnotation alloc]init];
                     point1.title=name;
                     point1.subtitle=description.subLocality;
                     point1.coordinate=location2D;
                     [self.mapview addAnnotation:point1];
                     
                     
                 }];
                
            }

        
        //}
        
        [self.tableview reloadData];
        
    }];
    
    [task1 resume];
    
    
    
    
//NSURLSessionDataTask *task2=[session dataTaskWithRequest:req completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
//        
//        
//NSDictionary *outerdic=[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
//        
////if ([_typestring isEqualToString:_typestring])
////{
//            
//    NSArray *resultarr=[outerdic objectForKey:@"results"];
//    for(NSDictionary *tempdic in resultarr)
//    {
//     NSString *entityname=[tempdic objectForKey:@"name"];
//
//     NSDictionary *geometry=[tempdic objectForKey:@"geometry"];
//     NSDictionary *locat=[geometry objectForKey:@"location"];
//     NSNumber *lat=[locat objectForKey:@"lat"];
//     NSNumber *longg=[locat objectForKey:@"lng"];
//     NSLog(@"%@  %@ ",lat,longg);
//            
//                
//    CLLocation *location = [[CLLocation alloc] initWithLatitude:[lat doubleValue] longitude:[longg doubleValue]];
//                
//    CLLocationCoordinate2D location2D;
//    location2D.latitude=[lat doubleValue];
//    location2D.longitude=[longg doubleValue];
//                
//                
//     [_geocoder reverseGeocodeLocation:location completionHandler:^(NSArray *placemarks, NSError *error)
//     {
//         description=[placemarks objectAtIndex:0];
//        // NSLog(@"%@",description);
//         
//         MKPointAnnotation *point1=[[MKPointAnnotation alloc]init];
//         point1.title=entityname;
//         point1.subtitle=description.subLocality;
//         point1.coordinate=location2D;
//         [self.mapview addAnnotation:point1];
//
//
//     }];
//    
//   }
////}
//        
//        //[self.tableview reloadData];
//        
//}];
//    
//    [task2 resume];

    
    
    _mapview.hidden=YES;
    
}
-(MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id<MKAnnotation>)annotation
{

    MKPinAnnotationView *pin=[[MKPinAnnotationView alloc]initWithAnnotation:annotation reuseIdentifier:nil];
    
    pin.canShowCallout=YES;
    
    // pin.pinTintColor=[UIColor blueColor];
    
    // pin.pinColor=MKPinAnnotationColorPurple;
    
    pin.pinTintColor=[UIColor redColor];
    UIButton *btn=[UIButton buttonWithType:UIButtonTypeInfoDark];
    [btn addTarget:self action:@selector(btnclick) forControlEvents:UIControlEventTouchUpInside];
    pin.rightCalloutAccessoryView=btn;
    return pin;
}

-(void)btnclick
{
    NSLog(@"button click");
    
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    //#warning Potentially incomplete method implementation.
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    //#warning Incomplete method implementation.
    // Return the number of rows in the section.
    return _namearr.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    CustomTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    
    // Configure the cell...
    
    cell.namelbl.text=[_namearr objectAtIndex:indexPath.row];
    cell.addlbl.text=[_addarr objectAtIndex:indexPath.row];
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    return 100;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


- (IBAction)segmentchange:(id)sender {
    if(_segmentedcontrol.selectedSegmentIndex==0)
    {
        [self.mapview setHidden:YES];
        _tableview.hidden=NO;
        
    }
    if(_segmentedcontrol.selectedSegmentIndex==1)
    {
        [self.tableview setHidden:YES];
        _mapview.hidden=NO;
        
    }
    
}
@end
