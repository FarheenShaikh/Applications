//
//  SecondViewController.h
//  collection1
//
//  Created by student14 on 31/01/17.
//  Copyright © 2017 Student. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>

@interface SecondViewController : UIViewController<UITableViewDelegate,UITableViewDataSource,CLLocationManagerDelegate,MKMapViewDelegate>


@property(nonatomic,retain)NSString *typestring;
@property(nonatomic,retain)NSMutableArray *namearr,*addarr;

@property (weak, nonatomic) IBOutlet UISegmentedControl *segmentedcontrol;


- (IBAction)segmentchange:(id)sender;

@property (weak, nonatomic) IBOutlet MKMapView *mapview;
@property (weak, nonatomic) IBOutlet UITableView *tableview;

@property(nonatomic,retain)CLGeocoder *geocoder;
@property(nonatomic,retain)CLLocationManager *manager;

@end
