//
//  CollectionViewController.h
//  collection1
//
//  Created by Student on 28/12/16.
//  Copyright (c) 2016 Student. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CollectionViewController : UICollectionViewController<UICollectionViewDelegateFlowLayout>


@property(nonatomic,retain)NSArray *imagearray,*namearray,*name1array;
@property CGPoint p;
@end
