//
//  FirstViewController.h
//  Prime number
//
//  Created by Student on 30/11/16.
//  Copyright (c) 2016 Student. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FirstViewController : UIViewController

@property(nonatomic,retain)UITextField *tf1;
@property(nonatomic,retain)UIButton *btn;

@property(nonatomic,retain)UIAlertView *alert;

@end
