//
//  forecastTableViewCell.h
//  weather
//
//  Created by Student on 05/01/17.
//  Copyright (c) 2017 Student. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface forecastTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *datelbl;
@property (weak, nonatomic) IBOutlet UILabel *templabl;

@property (weak, nonatomic) IBOutlet UILabel *desclbl;
@property (weak, nonatomic) IBOutlet UIImageView *imgview;

@end
