//
//  forecastTableViewCell.m
//  weather
//
//  Created by Student on 05/01/17.
//  Copyright (c) 2017 Student. All rights reserved.
//

#import "forecastTableViewCell.h"

@implementation forecastTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
