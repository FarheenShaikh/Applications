//
//  ThirdableViewController.h
//  weather
//
//  Created by Student on 05/01/17.
//  Copyright (c) 2017 Student. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ThirdableViewController : UITableViewController
@property NSString *newtempstring;
@property(nonatomic,retain)NSMutableArray *datearray,*tempraturearr,*descriptionarr;
@property(nonatomic,retain)NSDecimalNumber *result;

@end
