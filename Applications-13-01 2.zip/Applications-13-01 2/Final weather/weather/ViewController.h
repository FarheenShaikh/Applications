//
//  ViewController.h
//  weather
//
//  Created by Student on 26/12/16.
//  Copyright (c) 2016 Student. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITextField *citytf;

@end

