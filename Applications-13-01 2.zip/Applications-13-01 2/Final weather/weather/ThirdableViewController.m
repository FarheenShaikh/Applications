//
//  ThirdableViewController.m
//  weather
//
//  Created by Student on 05/01/17.
//  Copyright (c) 2017 Student. All rights reserved.
//

#import "ThirdableViewController.h"
#import "forecastTableViewCell.h"

@interface ThirdableViewController ()

@end

@implementation ThirdableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _datearray=[[NSMutableArray alloc]init];
    _tempraturearr=[[NSMutableArray alloc]init];
    _descriptionarr=[[NSMutableArray alloc]init];
    
    
    NSURL *url=[NSURL URLWithString:[NSString stringWithFormat:@"http://api.openweathermap.org/data/2.5/forecast?q=%@&APPID=acfa76c29d473ed69abb1b69ddf3f421",_newtempstring]];
    
    NSMutableURLRequest *req=[NSMutableURLRequest requestWithURL:url];
    NSURLSessionConfiguration *conf=[NSURLSessionConfiguration defaultSessionConfiguration];
    
    NSURLSession *session=[NSURLSession sessionWithConfiguration:conf];
    
    
    
    NSURLSessionDataTask *task1=[session dataTaskWithRequest:req completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        
        NSDictionary *outerdic=[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        NSArray *outerarray=[outerdic objectForKey:@"list"];
        
        for(NSDictionary *temp in outerarray)
        {
            NSString *date=[temp objectForKey:@"dt_txt"];
            NSLog(@"%@",date);
            [_datearray addObject:date];
            
            
            //For temperature
            NSDictionary *maindict=[temp objectForKey:@"main"];
            NSNumber *temprtr=[maindict objectForKey:@"temp"];
            
            
            NSDecimalNumber *conversionnum=[[NSDecimalNumber alloc]initWithString:@"273.15"];
            
            NSDecimalNumber *decnum= [NSDecimalNumber decimalNumberWithDecimal:[temprtr decimalValue]];
            
            _result=[decnum decimalNumberBySubtracting:conversionnum];
            [_tempraturearr addObject:[NSString stringWithFormat:@"%@",_result]];
            NSLog(@"%@",_result);
            
            
            NSArray *weatherarr=[temp objectForKey: @"weather"];
            NSDictionary *inndic=[weatherarr objectAtIndex:0];
            NSString *desc=[inndic objectForKey:@"description"];
            [_descriptionarr addObject:desc];
            NSLog(@"%@",desc);
            
            
            
        }
        
        
        [self.tableView reloadData];
        
        
        
    }];
    [task1 resume];
    
    
    
    [self.tableView registerNib:[UINib nibWithNibName:@"forecastTableViewCell" bundle:[NSBundle mainBundle]] forCellReuseIdentifier:@"cell"];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    return _datearray.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    forecastTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    
    // Configure the cell...
 cell.datelbl.text=[_datearray objectAtIndex:indexPath.row];
 cell.templabl.text=[_tempraturearr objectAtIndex:indexPath.row];
 cell.desclbl.text=[_descriptionarr objectAtIndex:indexPath.row];

 
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 150;

}


/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
