//
//  ViewController.m
//  Timetable
//
//  Created by Student on 28/11/16.
//  Copyright (c) 2016 Student. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    _tableview.delegate=self;
    _tableview.dataSource=self;
    
    
    _stringarray=[[NSMutableArray alloc]init];
    
    [self.tableview registerClass:[UITableViewCell class] forCellReuseIdentifier:@"cell"];
    
    
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView

{
    return 1;

}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
   // _num=[NSString stringWithFormat:@"%@",_tf2.text];
    
    _num2=[_tf2.text intValue];
    return _num2;

}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    
    cell.textLabel.text=[_stringarray objectAtIndex:indexPath.row];
    return cell;

}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.tableview reloadData];
}

- (IBAction)calculatebtn:(id)sender {
    [self.tableview reloadData];
    _num1=[_tf1.text intValue];
    
    
    for(int i=1;i<=_num2;i++)
    {
        for(int j=1;j<=_num2;j++)
        {
    NSString *str=[NSString stringWithFormat:@"%d * %d = %d",_num1,j,(_num1*j)];
        [_stringarray addObject:str];
        }
    }
    
    
    
}
@end
