//
//  ViewController.h
//  Timetable
//
//  Created by Student on 28/11/16.
//  Copyright (c) 2016 Student. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UITableViewDelegate,UITableViewDataSource>

@property (weak, nonatomic) IBOutlet UITextField *tf1;

@property (weak, nonatomic) IBOutlet UITextField *tf2;

- (IBAction)calculatebtn:(id)sender;

@property (weak, nonatomic) IBOutlet UITableView *tableview;
@property int num1,num2;
@property(nonatomic,retain)NSMutableArray *stringarray;


@end
