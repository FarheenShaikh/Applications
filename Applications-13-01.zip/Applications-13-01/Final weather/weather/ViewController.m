//
//  ViewController.m
//  weather
//
//  Created by Student on 26/12/16.
//  Copyright (c) 2016 Student. All rights reserved.
//

#import "ViewController.h"
#import "SecondTableViewController.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if([[segue identifier]isEqualToString:@"fvctosvc"])
    {
    SecondTableViewController *svc=[segue destinationViewController];
    svc.tempstring=_citytf.text;
    }

}
@end
