//
//  SecondTableViewController.h
//  weather
//
//  Created by Student on 29/12/16.
//  Copyright (c) 2016 Student. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SecondTableViewController : UITableViewController<NSURLConnectionDelegate,NSURLConnectionDataDelegate>

@property(nonatomic,retain)NSMutableArray *keyarray,*valuearray,*newarray;
@property NSMutableData *mydata;
@property NSString *tempstring;
@property(nonatomic,retain)NSDecimalNumber *res;
//@property(nonatomic,retain)NSMutableDictionary *dictionary;



@end
