//
//  SecondTableViewController.m
//  weather
//
//  Created by Student on 29/12/16.
//  Copyright (c) 2016 Student. All rights reserved.
//

#import "SecondTableViewController.h"
#import "CustomTableViewCell.h"
#import "ThirdableViewController.h"

@interface SecondTableViewController ()

@end

@implementation SecondTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    _res=[[NSDecimalNumber alloc]init];
    _newarray=[[NSMutableArray alloc]init];
    
    
    
    _keyarray=[[NSMutableArray alloc]initWithObjects:@"Temperature",@"Cloudiness",@"Pressure",@"Humidity",@"Sunrise",@"Sunset",@"Latitude",@"Longitude", nil];
    
    
    _valuearray=[[NSMutableArray alloc]init];
    
    
    
    [self.tableView registerNib:[UINib nibWithNibName:@"CustomTableViewCell" bundle:[NSBundle mainBundle]] forCellReuseIdentifier:@"cell"];
    
    
    
    NSURL *url=[NSURL URLWithString:[NSString stringWithFormat:@"http://api.openweathermap.org/data/2.5/weather?q=%@&APPID=acfa76c29d473ed69abb1b69ddf3f421",_tempstring]];
    
    
    
    
    NSMutableURLRequest *req=[NSMutableURLRequest requestWithURL:url];
    NSURLSessionConfiguration *conf=[NSURLSessionConfiguration defaultSessionConfiguration];
   
    NSURLSession *session=[NSURLSession sessionWithConfiguration:conf];
    
    
    
    NSURLSessionDataTask *task1=[session dataTaskWithRequest:req completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        
        
        
        NSDecimalNumber *conversionnum=[[NSDecimalNumber alloc]initWithString:@"273.15"];

        NSDictionary *outerdic=[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        NSDictionary *temp=[outerdic objectForKey:@"main"];
        NSNumber *num=[temp objectForKey:@"temp"];
        
        //we get temperature in kelvin format.So we need to convert kelvin to celcious.
        
        
        //convert nsnumber into decimal number
        NSDecimalNumber *decnum= [NSDecimalNumber decimalNumberWithDecimal:[num decimalValue]];
        
        _res=[decnum decimalNumberBySubtracting:conversionnum];
        
        
     //   [_dictionary setObject:_res forKey:@"Temperature"];
        [_valuearray addObject:[NSString stringWithFormat:@"%@",_res]];
        
        
        NSArray *arr=[outerdic objectForKey:@"weather"];
              NSDictionary *dict=[arr objectAtIndex:0];
            NSString *desc=[dict objectForKey:@"description"];
        
       [_valuearray addObject:desc];
        
        
        NSNumber *press=[temp objectForKey:@"pressure"];
    
        NSString *pressure=[NSString stringWithFormat:@"%@",press];
        [_valuearray addObject:pressure];
        
        
        NSNumber *hum=[temp objectForKey:@"humidity"];
        NSString *humidity=[NSString stringWithFormat:@"%@",hum];
        [_valuearray addObject:humidity];
        
        
        NSDictionary *tempdic=[outerdic objectForKey:@"sys"];
        
     //  NSNumber *sunrise=[tempdic objectForKey:@"sunrise"];
//        NSNumber *sunset=[tempdic objectForKey:@"sunset"];
        
//        NSString *sunr=[NSString stringWithFormat:@"%@",sunrise];
//        NSString *suns=[NSString stringWithFormat:@"%@",sunset];
//        [_valuearray addObject:sunr];
//        [_valuearray addObject:suns];
        
        
      //  NSString *timestring=[NSString stringWithFormat:@"%@",sunrise];
      //  NSLog(@"%@",timestring);
//        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
//        [dateFormatter setDateFormat:@"dd-MM-yyyy HH:mm"];
//        
//        NSDate *dateFromString = [[NSDate alloc] init];
//        // voila!
//        dateFromString = [dateFormatter dateFromString:timestring];
//        
//        NSLog(@"%@",[dateFormatter stringFromDate:dateFromString]);

        
        
//        double timestampval =  [[tempdic objectForKey:@"sunrise"] integerValue]/1000;
//        NSTimeInterval timestamp = (NSTimeInterval)timestampval;
//        NSDate *updatetimestamp = [NSDate dateWithTimeIntervalSince1970:timestamp];
//        
//        NSLog(@"%@",updatetimestamp);
        
        
        NSNumber *snrnumber=[tempdic objectForKey:@"sunrise"];
        NSNumber *snstnumber=[tempdic objectForKey:@"sunset"];
      //  int unixTimeStamp =[tempdic objectForKey:@"sunrise"];
        
        double unixTimeStamp=[snrnumber doubleValue];
        double unixTimeStamp1=[snstnumber doubleValue];
        NSTimeInterval interval=(NSTimeInterval)unixTimeStamp;
        NSTimeInterval interval1=(NSTimeInterval)unixTimeStamp1;

       // NSTimeInterval timestamp=(NSTimeInterval)unixTimeStamp;
        NSDate *date = [NSDate dateWithTimeIntervalSince1970:interval];
        NSDate *date1 = [NSDate dateWithTimeIntervalSince1970:interval1];
        
        NSLog(@"%@   %@",date,date1);

        NSDateFormatter *formatter= [[NSDateFormatter alloc] init];
       [formatter setLocale:[NSLocale currentLocale]];
        
    //    [formatter setTimeZone:[NSTimeZone timeZoneWithAbbreviation:@"GMT"]];
        [formatter setDateFormat:@"HH:MM:SS"];
        NSString *sunrisetime = [formatter stringFromDate:date];
        NSString *sunsettime = [formatter stringFromDate:date1];


//         NSLog(@"%@",sunrisetime);
//        NSLog(@"%@",sunsettime);
        
        [_valuearray addObject:sunrisetime];
        [_valuearray addObject:sunsettime];

        
        
        
//
        
        NSDictionary *corddic=[outerdic objectForKey:@"coord"];
        
        NSNumber *lat=[corddic objectForKey:@"lat"];
        NSNumber *longg=[corddic objectForKey:@"lon"];
        NSLog(@"%@ %@",lat,longg);
        
        NSString *lattitude=[NSString stringWithFormat:@"%@",lat];
        NSString *longitude=[NSString stringWithFormat:@"%@",longg];
        
        [_valuearray addObject:lattitude];
        [_valuearray addObject:longitude];
        [self.tableView reloadData];
        

        
        
    }];
    

    [task1 resume];
    
    
    
    
//
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    return _valuearray.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    CustomTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    
    // Configure the cell...
    cell.keylbl.text=[_keyarray objectAtIndex:indexPath.row];
   cell.valuelbl.text=[_valuearray objectAtIndex:indexPath.row];
    
    //cell.keylbl.text=[_newarray objectAtIndex:indexPath.row];
   // cell.valuelbl.text=[_dictionary objectForKey:indexPath.row];
    
    
 //   [_valuearray objectAtIndex:[NSString stringWithFormat:@"%i", indexPath.row]];
    
    return cell;
}

-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
  NSString *title=[NSString stringWithFormat:@"Todays Weather %@°C",_res];
    return title;
}


/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    
    if([[segue identifier]isEqualToString:@"svctotvc"])
    {
        ThirdableViewController *tvc=[segue destinationViewController];
        tvc.newtempstring=_tempstring;
    }
}


@end
