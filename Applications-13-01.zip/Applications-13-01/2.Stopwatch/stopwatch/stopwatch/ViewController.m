//
//  ViewController.m
//  stopwatch
//
//  Created by Student on 14/12/16.
//  Copyright (c) 2016 Student. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    _lbl.text = @"00.00.00.000";
    running = FALSE;
    _date= [NSDate date];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)startbtnclick:(id)sender {
    
    
    _date=[NSDate date];
    _timer=[NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(updatetimer) userInfo:nil repeats:YES];
}

-(void)updatetimer
{
    NSDate *crntdate=[NSDate date];
    NSTimeInterval timeinterval=[crntdate timeIntervalSinceDate:self.date];
    NSDate *timerdate=[NSDate dateWithTimeIntervalSince1970:timeinterval];
    
    
    NSDateFormatter *dateformatter=[[NSDateFormatter alloc]init];
    [dateformatter setDateFormat:@"HH:mm:ss.SSS"];
    [dateformatter setTimeZone:[NSTimeZone timeZoneForSecondsFromGMT:0.1]];
    
    NSString *timestring=[dateformatter stringFromDate:timerdate];
    
    self.lbl.text=timestring;
    
    
}
- (IBAction)stopbtnclick:(id)sender {
    [_timer invalidate];
    [self updatetimer];
    
}

- (IBAction)resetbtnclick:(id)sender {
    [_timer invalidate];
    _timer=nil;
    
    _date=[NSDate date];
    
    _lbl.text=@"00.00.00.000";
    running=FALSE;
    

    
}
@end
