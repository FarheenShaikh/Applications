//
//  ViewController.h
//  stopwatch
//
//  Created by Student on 14/12/16.
//  Copyright (c) 2016 Student. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
 bool running;
}

@property (weak, nonatomic) IBOutlet UILabel *lbl;
@property(nonatomic,retain)NSDate *date;
@property(nonatomic,retain)NSTimer *timer;



- (IBAction)startbtnclick:(id)sender;
- (IBAction)stopbtnclick:(id)sender;

- (IBAction)resetbtnclick:(id)sender;

@end

