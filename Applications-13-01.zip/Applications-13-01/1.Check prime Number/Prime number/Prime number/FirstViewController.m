//
//  FirstViewController.m
//  Prime number
//
//  Created by Student on 30/11/16.
//  Copyright (c) 2016 Student. All rights reserved.
//

#import "FirstViewController.h"


@interface FirstViewController ()

@end

@implementation FirstViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.view.backgroundColor=[UIColor blueColor];
    _tf1=[[UITextField alloc]initWithFrame:CGRectMake(50, 100, 200, 50)];
    
    _tf1.backgroundColor=[UIColor whiteColor];
    
    _tf1.placeholder=@"Enter number";
    
    [self.view addSubview:_tf1];
    
    
    _btn=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    _btn.frame=CGRectMake(100, 200, 100, 50);
    [_btn setTitle:@"Check" forState:UIControlStateNormal];
    _btn.backgroundColor=[UIColor greenColor];
    [_btn addTarget:self action:@selector(btnclick) forControlEvents:UIControlEventTouchUpInside];
    
    [self.view addSubview:_btn];
}

-(void)btnclick
{
    int n=[_tf1.text intValue];
    int count=0;
    
    for(int i=1;i<=n;i++)
    {
       if(n%i==0)
       {
           count++;
       }
    }
    
    if(count==2)
    {
       //_lbl.text=@"Number is prime";
        _alert=[[UIAlertView alloc]initWithTitle:@"Check Prime app" message:@"Number is prime" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"OK", nil];
        [_alert show];
    }
       
    else
    {//   _lbl.text=@"Number is not prime";
        _alert=[[UIAlertView alloc]initWithTitle:@"Check Prime app" message:@"Number is not prime" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"OK", nil];
        [_alert show];


    }

}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
