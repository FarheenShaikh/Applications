//
//  ViewController.m
//  calculator
//
//  Created by Student on 28/11/16.
//  Copyright (c) 2016 Student. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)calculatebtn:(id)sender {
    
    int num1=[_tf1.text intValue];
 int num2=[_tf2.text intValue];
    float ans;
   // _ans=_num1 + _num2;
    if(_segment.selectedSegmentIndex==0)
         ans=num1+num2;
    else if(_segment.selectedSegmentIndex==1)
        ans=num1-num2;
    else if(_segment.selectedSegmentIndex==2)
        ans=num1*num2;
    else
        ans=num1/num2;
    
    _anstf.text=[NSString stringWithFormat:@"%f",ans];
    
}
@end
