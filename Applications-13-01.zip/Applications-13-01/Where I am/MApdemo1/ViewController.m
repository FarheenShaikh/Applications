//
//  ViewController.m
//  MApdemo1
//
//  Created by Student on 29/12/16.
//  Copyright (c) 2016 Student. All rights reserved.
//

#import "ViewController.h"
#import "SecondViewController.h"

@interface ViewController ()

@end
CLPlacemark *description;
@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    _manager=[[CLLocationManager alloc]init];
    _manager.delegate=self;
    _manager.desiredAccuracy=kCLLocationAccuracyBest;
    [_manager startUpdatingLocation];
    
    _geocoder=[[CLGeocoder alloc]init];
    
    [self.manager requestAlwaysAuthorization];

    
//    MKPointAnnotation *point1=[[MKPointAnnotation alloc]init];
//    
//    point1.title=@"Swargate";
//    point1.subtitle=@"Pune";
//    
//    CLLocationCoordinate2D location;
//    location.latitude=18.5004866;
//    location.longitude=73.8668996;
//    
//    point1.coordinate=location;
//
//    [self.map addAnnotation:point1];

}
-(void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations
{
    CLLocation *currentlocation=[locations lastObject];
   // NSLog(@"%@",currentlocation);
    
    
    [_geocoder reverseGeocodeLocation:currentlocation completionHandler:^(NSArray *placemarks, NSError *error) {
      
        description=[placemarks objectAtIndex:0];
        NSLog(@"%@",description);
        
        MKPointAnnotation *point1=[[MKPointAnnotation alloc]init];
        
     //   point1.title=@"Swargate";
     //   point1.subtitle=@"Pune";
        
        point1.title=description.subLocality;
        point1.subtitle=description.country;
    
        
        CLLocationCoordinate2D location;
        location.latitude=currentlocation.coordinate.latitude;
        location.longitude=currentlocation.coordinate.longitude;
        
        point1.coordinate=location;
        
        [self.map addAnnotation:point1];

        
    }];
    
    
    

}



-(MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id<MKAnnotation>)annotation
{
    MKPinAnnotationView *pin=[[MKPinAnnotationView alloc]initWithAnnotation:annotation reuseIdentifier:nil];
    
    pin.canShowCallout=YES;
    
   // pin.pinTintColor=[UIColor blueColor];
    
   // pin.pinColor=MKPinAnnotationColorPurple;
    
    pin.pinTintColor=[UIColor redColor];
    UIButton *btn=[UIButton buttonWithType:UIButtonTypeInfoDark];
    [btn addTarget:self action:@selector(btnclick) forControlEvents:UIControlEventTouchUpInside];
    pin.rightCalloutAccessoryView=btn;
    
   // [self.map addAnnotation:pin];
    return pin;
    

}
-(void)btnclick
{
    NSLog(@"button click");

}


-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    SecondViewController *svc=[segue destinationViewController];
    svc.sourcePlacemark=description;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
