//
//  ViewController.h
//  MApdemo1
//
//  Created by Student on 29/12/16.
//  Copyright (c) 2016 Student. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import <CoreLocation/CoreLocation.h>

@interface ViewController : UIViewController<MKMapViewDelegate,CLLocationManagerDelegate>


@property (weak, nonatomic) IBOutlet MKMapView *map;
@property(nonatomic,retain)CLLocationManager *manager;
@property(nonatomic,retain)CLGeocoder *geocoder;

@end

