//
//  SecondViewController.h
//  MApdemo1
//
//  Created by student14 on 12/01/17.
//  Copyright © 2017 Student. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import <CoreLocation/CoreLocation.h>




@interface SecondViewController : UIViewController<MKMapViewDelegate,CLLocationManagerDelegate>


- (IBAction)searchtextfield:(id)sender;

@property (weak, nonatomic) IBOutlet MKMapView *mapview;
@property (weak, nonatomic) IBOutlet UILabel *distancelbl;

- (void)addAnnotation:(CLPlacemark *)placemark;
- (IBAction)getroutebtn:(id)sender;
@property (weak, nonatomic) IBOutlet UILabel *destinationlbl;
@property (weak, nonatomic) IBOutlet UILabel *transportlbl;
@property (weak, nonatomic) IBOutlet UITextView *steps;


@property (strong, nonatomic) NSString *allSteps;
@property CLPlacemark *sourcePlacemark;



@end
