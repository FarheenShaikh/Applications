//
//  TableViewController.h
//  jsonparsing-2
//
//  Created by Student on 15/12/16.
//  Copyright (c) 2016 Student. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableViewController : UITableViewController<NSURLConnectionDelegate,NSURLConnectionDataDelegate>

@property(nonatomic,retain)NSMutableArray *namearray;
@property(nonatomic,retain)NSMutableData *mydata;
@end
