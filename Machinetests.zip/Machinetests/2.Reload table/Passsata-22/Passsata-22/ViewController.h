//
//  ViewController.h
//  Passsata-22
//
//  Created by Student on 25/11/16.
//  Copyright (c) 2016 Student. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@property(nonatomic,retain)NSMutableArray *temparray;

@property (weak, nonatomic) IBOutlet UITextField *tf1;
- (IBAction)addbtn:(id)sender;


@end
