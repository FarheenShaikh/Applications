//
//  Department.m
//  company-mgmt
//
//  Created by Felix-ITS 013 on 10/02/17.
//  Copyright © 2017 Felix013. All rights reserved.
//

#import "Department.h"
#import "Company.h"
#import "Employee.h"

@implementation Department

// Insert code here to add functionality to your managed object subclass

@end
