//
//  finddetailsViewController.h
//  company-mgmt
//
//  Created by Felix-ITS 013 on 13/02/17.
//  Copyright © 2017 Felix013. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface finddetailsViewController : UIViewController

@property (strong, nonatomic) IBOutlet UITextField *empidtf;
@property (strong, nonatomic) IBOutlet UILabel *empnametf;

- (IBAction)searchforempbtn:(id)sender;
@property (strong, nonatomic) IBOutlet UILabel *companylbl;
@property (strong, nonatomic) IBOutlet UILabel *deptlabel;

@end
