//
//  Department+CoreDataProperties.h
//  company-mgmt
//
//  Created by Felix-ITS 013 on 10/02/17.
//  Copyright © 2017 Felix013. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "Department.h"

NS_ASSUME_NONNULL_BEGIN

@interface Department (CoreDataProperties)

@property (nullable, nonatomic, retain) NSNumber *deptid;
@property (nullable, nonatomic, retain) NSString *deptname;
@property (nullable, nonatomic, retain) NSSet<Employee *> *has;
@property (nullable, nonatomic, retain) Company *presenting;

@end

@interface Department (CoreDataGeneratedAccessors)

- (void)addHasObject:(Employee *)value;
- (void)removeHasObject:(Employee *)value;
- (void)addHas:(NSSet<Employee *> *)values;
- (void)removeHas:(NSSet<Employee *> *)values;

@end

NS_ASSUME_NONNULL_END
