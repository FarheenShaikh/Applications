//
//  finddetailsViewController.m
//  company-mgmt
//
//  Created by Felix-ITS 013 on 13/02/17.
//  Copyright © 2017 Felix013. All rights reserved.
//

#import "finddetailsViewController.h"
#import "AppDelegate.h"
#import "Company.h"
#import "Department.h"
#import "Employee.h"

@interface finddetailsViewController ()

@end

@implementation finddetailsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)searchforempbtn:(id)sender {
    UIApplication *myapplication=[UIApplication sharedApplication];
    AppDelegate *mydelegate=(AppDelegate *)myapplication.delegate;
    
    NSManagedObjectContext *context=mydelegate.managedObjectContext;
    
    NSFetchRequest *request=[NSFetchRequest fetchRequestWithEntityName:@"Company"];
    NSArray *res=[context executeFetchRequest:request error:nil];
    
    for(Company *c in res)
    {
        NSLog(@"%@",c.compname);
        
        for(Department *d in c.contains)
        {
            NSLog(@"%@ %@",c.compname,d.deptname );

            
            for(Employee *e in d.has)
            {

                NSNumber *n=[NSNumber numberWithInt:[ _empidtf.text intValue]] ;
              
                if([[e empid]isEqualToNumber:n])
                {

                _empnametf.text=e.empname;
                _deptlabel.text=d.deptname;
                _companylbl.text=c.compname;
                    
                }
            
            }
            
            
        }

  }
    
    

    
    
}
@end
