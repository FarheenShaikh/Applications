//
//  Department+CoreDataProperties.m
//  company-mgmt
//
//  Created by Felix-ITS 013 on 10/02/17.
//  Copyright © 2017 Felix013. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "Department+CoreDataProperties.h"

@implementation Department (CoreDataProperties)

@dynamic deptid;
@dynamic deptname;
@dynamic has;
@dynamic presenting;

@end
