//
//  Company.m
//  company-mgmt
//
//  Created by Felix-ITS 013 on 10/02/17.
//  Copyright © 2017 Felix013. All rights reserved.
//

#import "Company.h"
#import "Department.h"
#import "Employee.h"

@implementation Company

// Insert code here to add functionality to your managed object subclass

@end
