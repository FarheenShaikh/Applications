//
//  Company+CoreDataProperties.h
//  company-mgmt
//
//  Created by Felix-ITS 013 on 10/02/17.
//  Copyright © 2017 Felix013. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "Company.h"

NS_ASSUME_NONNULL_BEGIN

@interface Company (CoreDataProperties)

@property (nullable, nonatomic, retain) NSNumber *compid;
@property (nullable, nonatomic, retain) NSString *compname;
@property (nullable, nonatomic, retain) NSSet<Department *> *contains;
@property (nullable, nonatomic, retain) NSSet<Employee *> *containsemp;

@end

@interface Company (CoreDataGeneratedAccessors)

- (void)addContainsObject:(Department *)value;
- (void)removeContainsObject:(Department *)value;
- (void)addContains:(NSSet<Department *> *)values;
- (void)removeContains:(NSSet<Department *> *)values;

- (void)addContainsempObject:(Employee *)value;
- (void)removeContainsempObject:(Employee *)value;
- (void)addContainsemp:(NSSet<Employee *> *)values;
- (void)removeContainsemp:(NSSet<Employee *> *)values;

@end

NS_ASSUME_NONNULL_END
