//
//  Employee.h
//  company-mgmt
//
//  Created by Felix-ITS 013 on 10/02/17.
//  Copyright © 2017 Felix013. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class Company, Department;

NS_ASSUME_NONNULL_BEGIN

@interface Employee : NSManagedObject

// Insert code here to declare functionality of your managed object subclass

@end

NS_ASSUME_NONNULL_END

#import "Employee+CoreDataProperties.h"
