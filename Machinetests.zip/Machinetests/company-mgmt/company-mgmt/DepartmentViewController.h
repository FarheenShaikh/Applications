//
//  DepartmentViewController.h
//  company-mgmt
//
//  Created by Felix-ITS 013 on 10/02/17.
//  Copyright © 2017 Felix013. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DepartmentViewController : UIViewController<UIPickerViewDelegate,UIPickerViewDataSource>

@property (strong, nonatomic) IBOutlet UITextField *deptidtf;

@property (strong, nonatomic) IBOutlet UITextField *deptnametf;
@property (strong, nonatomic) IBOutlet UIPickerView *comppicker;
@property NSString *temp;

- (IBAction)savedepartment:(id)sender;
@property(nonatomic,retain)NSMutableArray *company;

@end
