//
//  DepartmentViewController.m
//  company-mgmt
//
//  Created by Felix-ITS 013 on 10/02/17.
//  Copyright © 2017 Felix013. All rights reserved.
//

#import "DepartmentViewController.h"
#import "AppDelegate.h"
#import "Department.h"
#import "Company.h"

@interface DepartmentViewController ()

@end

@implementation DepartmentViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    _company=[[NSMutableArray alloc]init];
    
    UIApplication *myapplication=[UIApplication sharedApplication];
    
    AppDelegate *myappdelegate=(AppDelegate *)myapplication.delegate;
    
    NSManagedObjectContext *context=myappdelegate.managedObjectContext;
    
    NSFetchRequest *request=[NSFetchRequest fetchRequestWithEntityName:@"Company"];
    
    NSArray *arry=[context executeFetchRequest:request error:nil];
    
    for (Company *comp in arry)
    {
        
        
        [_company addObject:comp.compname];
        
    }
    NSLog(@"%@",_company);
    [self.comppicker reloadAllComponents];
    

}
-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    
    return 1;
    
}

-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    return _company.count;
    
}


-(NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    
    return [_company objectAtIndex:row];
}

-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component{
    
    
    int row1 =[pickerView selectedRowInComponent:0];
    
    _temp=[_company objectAtIndex:row1];
    
    NSLog(@"%@",_temp);
    
    
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)savedepartment:(id)sender {
    
    UIApplication *myapp=[UIApplication sharedApplication];
    AppDelegate *mydelegate=(AppDelegate *)myapp.delegate;
    NSManagedObjectContext *context=mydelegate.managedObjectContext;
    Department *d1=[NSEntityDescription insertNewObjectForEntityForName:@"Department" inManagedObjectContext:context];
    d1.deptid=[NSNumber numberWithInt:[_deptidtf.text intValue]];
    d1.deptname=_deptnametf.text;
    
    NSFetchRequest *request=[NSFetchRequest fetchRequestWithEntityName:@"Company"];
    
    NSArray *arry=[context executeFetchRequest:request error:nil];
    
    for (Company *comp in arry)
    {
        if ([[comp compname]isEqualToString:_temp])
        {
            [comp addContainsObject:d1];
            
            NSLog(@"%@",comp.compname);
            
        }
        
    }
    [context save:nil];
    NSLog(@"%@    %@   ",d1.deptid,d1.deptname);
    
    NSLog(@"Department Data Saved");
    
   // NSString *str=[NSString stringWithFormat:@"%@",_dnametf.text];
    
   // [_deptarray addObject:str];
    
    [self.comppicker reloadAllComponents];

    [self.navigationController popViewControllerAnimated:YES];

    
    
}

-(CGFloat)pickerView:(UIPickerView *)pickerView widthForComponent:(NSInteger)component
{
    
    return 200;
}


-(CGFloat)pickerView:(UIPickerView *)pickerView rowHeightForComponent:(NSInteger)component
{
    
    return 60;
}

@end
