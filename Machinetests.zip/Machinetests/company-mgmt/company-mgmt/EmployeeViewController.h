//
//  EmployeeViewController.h
//  company-mgmt
//
//  Created by Felix-ITS 013 on 10/02/17.
//  Copyright © 2017 Felix013. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EmployeeViewController : UIViewController<UIPickerViewDelegate,UIPickerViewDataSource>
@property (strong, nonatomic) IBOutlet UITextField *empidtf;

@property (strong, nonatomic) IBOutlet UITextField *empnametf;
@property (strong, nonatomic) IBOutlet UITextField *empsaltf;
@property (strong, nonatomic) IBOutlet UIPickerView *comppicker;

- (IBAction)saveemployee:(id)sender;
@property(nonatomic,retain)NSMutableArray *company,*deptarr;
@property(nonatomic,retain)NSString *dstr, *cstr;


@end
