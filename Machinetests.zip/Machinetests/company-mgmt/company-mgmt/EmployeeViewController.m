//
//  EmployeeViewController.m
//  company-mgmt
//
//  Created by Felix-ITS 013 on 10/02/17.
//  Copyright © 2017 Felix013. All rights reserved.
//

#import "EmployeeViewController.h"
#import "AppDelegate.h"
#import "Department.h"
#import "Company.h"
#import "Employee.h"

@interface EmployeeViewController ()

@end

@implementation EmployeeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    _company=[[NSMutableArray alloc]init];
    _deptarr=[[NSMutableArray alloc]init];
    _cstr=[[NSString alloc]init];
    _dstr=[[NSString alloc]init];

    UIApplication *myapplication=[UIApplication sharedApplication];
    
    AppDelegate *myappdelegate=(AppDelegate *)myapplication.delegate;
    
    NSManagedObjectContext *context=myappdelegate.managedObjectContext;
    
    NSFetchRequest *request=[NSFetchRequest fetchRequestWithEntityName:@"Company"];
    
    NSArray *arry=[context executeFetchRequest:request error:nil];
    
    for (Company *comp in arry)
    {
        
        NSString *str=[NSString stringWithFormat:@"%@",comp.compname];
        
        [_company addObject:str];
        
}
    NSLog(@"%@",_company);
    [self.comppicker reloadAllComponents];
    
    
    
    

    
}

-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    
    return 2;
}

-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    if (component==0)
        
        return _company.count;
    
    else
        
        return _deptarr.count;
    
    
}

-(NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component

{
    if (component==0)
    {
        
        return [_company objectAtIndex:row];
    }
    else
    {
        return [_deptarr objectAtIndex:row];
    }
    return nil;
}
-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    
  if(component==0)
  {
      [_deptarr removeAllObjects];
    UIApplication *app=[UIApplication sharedApplication];
    
    AppDelegate *mydelegate=(AppDelegate *)app.delegate;
    
    NSManagedObjectContext *context= mydelegate.managedObjectContext;
    
    NSFetchRequest *request=[NSFetchRequest fetchRequestWithEntityName:@"Company"];
    NSArray *cresult=[context executeFetchRequest:request error:nil];
    
    for (Company *comp in cresult)
    {
        
        _cstr=[_company objectAtIndex:row];
        
        if ([[comp compname]isEqualToString:_cstr])
        {
            
            for (Department *dept in comp.contains)
            {
                NSString *str1=[NSString stringWithFormat:@"%@",dept.deptname];
                
                _dstr=dept.deptname;
                [_deptarr addObject:str1];
            }
        }
        
    }
    [context save:nil];
      [self.comppicker reloadComponent:1];


  }
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)saveemployee:(id)sender {
    
    UIApplication *app=[UIApplication sharedApplication];
    
    AppDelegate *mydelegate=(AppDelegate *)app.delegate;
    
    NSManagedObjectContext *context= mydelegate.managedObjectContext;
    
    
    Employee *e1=[NSEntityDescription insertNewObjectForEntityForName:@"Employee" inManagedObjectContext:context];
    
    e1.empid=[NSNumber numberWithInt:[ _empidtf.text intValue]] ;
    
    e1.empname=_empnametf.text;
    
    e1.salary=[NSNumber numberWithInt:[_empsaltf.text intValue]];
    
    NSFetchRequest *request=[NSFetchRequest fetchRequestWithEntityName:@"Company"];
    NSArray *cresult=[context executeFetchRequest:request error:nil];
    
    for (Company *comp in cresult) {
        
        NSLog(@"%@",_cstr);
        
        if ([comp.compname isEqualToString:_cstr]) {
            
            for (Department *dept in comp.contains)
            {
                
                if([[dept deptname]isEqualToString:_dstr])
                {
                    
                    [dept addHasObject:e1];
                    
                    [comp addContainsObject:dept];
                    
                    NSLog(@"Data Saved");
                }
                
            }
        }
        
    }
    [context save:nil];
    
    
    
    
  

}
@end
