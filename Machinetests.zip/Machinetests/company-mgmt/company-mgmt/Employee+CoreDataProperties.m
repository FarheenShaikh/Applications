//
//  Employee+CoreDataProperties.m
//  company-mgmt
//
//  Created by Felix-ITS 013 on 10/02/17.
//  Copyright © 2017 Felix013. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "Employee+CoreDataProperties.h"

@implementation Employee (CoreDataProperties)

@dynamic empid;
@dynamic empname;
@dynamic salary;
@dynamic workfor;
@dynamic workingin;

@end
