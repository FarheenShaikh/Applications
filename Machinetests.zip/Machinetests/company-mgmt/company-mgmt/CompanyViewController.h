//
//  CompanyViewController.h
//  company-mgmt
//
//  Created by Felix-ITS 013 on 10/02/17.
//  Copyright © 2017 Felix013. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CompanyViewController : UIViewController


@property(nonatomic,retain)NSMutableArray *companyarray;
@property (strong, nonatomic) IBOutlet UITextField *compidtf;


@property (strong, nonatomic) IBOutlet UITextField *compnametf;
- (IBAction)savecompany:(id)sender;

@end
