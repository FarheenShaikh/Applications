//
//  Employee.m
//  company-mgmt
//
//  Created by Felix-ITS 013 on 10/02/17.
//  Copyright © 2017 Felix013. All rights reserved.
//

#import "Employee.h"
#import "Company.h"
#import "Department.h"

@implementation Employee

// Insert code here to add functionality to your managed object subclass

@end
