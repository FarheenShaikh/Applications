//
//  CompanyViewController.m
//  company-mgmt
//
//  Created by Felix-ITS 013 on 10/02/17.
//  Copyright © 2017 Felix013. All rights reserved.
//

#import "CompanyViewController.h"
#import "AppDelegate.h"
#import "Company.h"

@interface CompanyViewController ()

@end

@implementation CompanyViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    _companyarray=[[NSMutableArray alloc]init];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)savecompany:(id)sender {
    
    
    UIApplication *myapplication=[UIApplication sharedApplication];
    
    AppDelegate *mydelegate=(AppDelegate *)myapplication.delegate;
    
    NSManagedObjectContext *context=mydelegate.managedObjectContext;
    
    Company *c1=[NSEntityDescription insertNewObjectForEntityForName:@"Company" inManagedObjectContext:context];
    
    c1.compid=[NSNumber numberWithInt:[_compidtf.text intValue]];
    
    c1.compname=_compnametf.text;
    
    [context save:nil];
    
    
    
//    NSString *str=[NSString stringWithFormat:@"%@",_compnametf.text];
//    
//    [_companyarray addObject:str];
    
    NSFetchRequest *request=[NSFetchRequest fetchRequestWithEntityName:@"Company"];
    
    NSArray *arry=[context executeFetchRequest:request error:nil];
    
    for (Company *comp in arry)
    {
        
        NSLog(@"%@",comp.compname);

        
        
    }
    
    
    [self.navigationController popViewControllerAnimated:YES];
    

}
@end
