//
//  SecondViewController.h
//  storyboard-3
//
//  Created by Student on 30/11/16.
//  Copyright (c) 2016 Student. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SecondViewController : UIViewController


@property (weak, nonatomic) IBOutlet UILabel *lbl;
@property(nonatomic,retain)NSString *tempstring;

@end
