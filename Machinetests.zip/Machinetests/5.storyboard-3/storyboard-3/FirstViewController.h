//
//  FirstViewController.h
//  storyboard-3
//
//  Created by Student on 30/11/16.
//  Copyright (c) 2016 Student. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FirstViewController : UIViewController


@property (weak, nonatomic) IBOutlet UITextField *unametf;

@property (weak, nonatomic) IBOutlet UITextField *pstf;


@end
