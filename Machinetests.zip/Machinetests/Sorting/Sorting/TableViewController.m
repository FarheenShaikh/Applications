//
//  TableViewController.m
//  Sorting
//
//  Created by Student on 13/12/16.
//  Copyright (c) 2016 Student. All rights reserved.
//

#import "TableViewController.h"
#import "Employee.h"
#import "CustomTableViewCell.h"


@interface TableViewController ()

@end

@implementation TableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.tableView registerNib:[UINib nibWithNibName:@"CustomTableViewCell" bundle:[NSBundle  mainBundle]] forCellReuseIdentifier:@"cell"];
    
    Employee *e1=[[Employee alloc]init];
    e1.empid=1;
    e1.empname=@"Farheen";
    e1.designation=@"Manager";
    e1.salary=1234;
    
    Employee *e2=[[Employee alloc]init];
    e2.empid=2;
    e2.empname=@"Jyoti";
    e2.designation=@"Developer";
    e2.salary=1444;
    
    Employee *e3=[[Employee alloc]init];
    e3.empid=3;
    e3.empname=@"ABC";
    e3.designation=@"CEO";
    e3.salary=3334;
    
    _emparray =[[NSMutableArray alloc]init];
    
    [_emparray addObject:e1];
    [_emparray addObject:e2];
    [_emparray addObject:e3];
    
    
    
    
    
    
    
    
}
-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    
    
    
    _view1=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 320,100 )];
    _view1.backgroundColor=[UIColor redColor];
    [self.view addSubview:_view1];
    
    _lbl1=[[UILabel alloc]initWithFrame:CGRectMake(10, 10, 50, 30)];
    _lbl1.text=@"Sort by";
    [_view1 addSubview:_lbl1];
    
    _namebtn=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    _namebtn.frame=CGRectMake(70, 10, 50, 30);
    [_namebtn setTitle:@"Name" forState:UIControlStateNormal];
    [_namebtn addTarget:self action:@selector(sortbyname) forControlEvents:UIControlEventTouchUpInside];
    [_view1 addSubview:_namebtn];
    
    _salarybtn=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    _salarybtn.frame=CGRectMake(130, 10, 50, 30);
    [_salarybtn setTitle:@"Salary" forState:UIControlStateNormal];
    [_salarybtn addTarget:self action:@selector(sortbysalary) forControlEvents:UIControlEventTouchUpInside];
    [_view1 addSubview:_salarybtn];

    
    _desigbtn=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    _desigbtn.frame=CGRectMake(190, 10, 80, 30);
    [_desigbtn setTitle:@"Designation" forState:UIControlStateNormal];
    [_desigbtn addTarget:self action:@selector(sortbydesignation) forControlEvents:UIControlEventTouchUpInside];
    [_view1 addSubview:_desigbtn];

    
    
    return _view1;

}

-(void)sortbyname
{
    NSSortDescriptor *obj1=[[NSSortDescriptor alloc]initWithKey:@"empname" ascending:YES];

    [_emparray sortUsingDescriptors:@[obj1]];
//    NSMutableArray *sortedarray=[NSMutableArray arrayWithArray:_emparray];
//    _emparray=sortedarray;
    [self.tableView reloadData];
}

-(void)sortbysalary
{
    NSSortDescriptor *obj2=[[NSSortDescriptor alloc]initWithKey:@"salary" ascending:YES];
    [_emparray sortUsingDescriptors:@[obj2]];
    NSMutableArray *sortedarray=[NSMutableArray arrayWithArray:_emparray];
    _emparray=sortedarray;
    [self.tableView reloadData];
    
}


-(void)sortbydesignation
{
    NSSortDescriptor *obj3=[[NSSortDescriptor alloc]initWithKey:@"designation" ascending:YES];
    [_emparray sortUsingDescriptors:@[obj3]];
    
    
    NSMutableArray *sortedarray=[NSMutableArray arrayWithArray:_emparray];
    _emparray=sortedarray;
    [self.tableView reloadData];
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
//#warning Potentially incomplete method implementation.
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
//#warning Incomplete method implementation.
    // Return the number of rows in the section.
    return _emparray.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    CustomTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    
    // Configure the cell...
    Employee *temp=[_emparray objectAtIndex:indexPath.row];
    
    cell.idlbl.text=[NSString stringWithFormat:@"%i",temp.empid];
    cell.namelbl.text=temp.empname;
    cell.desiglbl.text=temp.designation;
    cell.sallbl.text=[NSString stringWithFormat:@"%i",temp.salary];
    
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 100;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 160;

}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
