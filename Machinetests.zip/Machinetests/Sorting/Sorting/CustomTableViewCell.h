//
//  CustomTableViewCell.h
//  Sorting
//
//  Created by Student on 13/12/16.
//  Copyright (c) 2016 Student. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *idlbl;
@property (weak, nonatomic) IBOutlet UILabel *namelbl;
@property (weak, nonatomic) IBOutlet UILabel *desiglbl;

@property (weak, nonatomic) IBOutlet UILabel *sallbl;
@end
