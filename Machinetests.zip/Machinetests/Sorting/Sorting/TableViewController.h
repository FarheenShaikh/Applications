//
//  TableViewController.h
//  Sorting
//
//  Created by Student on 13/12/16.
//  Copyright (c) 2016 Student. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableViewController : UITableViewController


@property(nonatomic,retain)UIView *view1;
@property(nonatomic,retain)UILabel *lbl1;

@property(nonatomic,retain)UIButton *namebtn,*salarybtn,*desigbtn;

@property(nonatomic,retain)NSMutableArray *emparray;

@end
