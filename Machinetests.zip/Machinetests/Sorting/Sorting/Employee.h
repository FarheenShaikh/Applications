//
//  Employee.h
//  Sorting
//
//  Created by Student on 13/12/16.
//  Copyright (c) 2016 Student. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Employee : NSObject


@property int empid;
@property(nonatomic,retain)NSString *empname;
@property(nonatomic,retain)NSString *designation;
@property int salary;

@end
