//
//  Employee.m
//  Sorting
//
//  Created by Student on 13/12/16.
//  Copyright (c) 2016 Student. All rights reserved.
//

#import "Employee.h"

@implementation Employee

@end
