//
//  ColorViewController.h
//  Slider
//
//  Created by Student on 28/11/16.
//  Copyright (c) 2016 Student. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ColorViewController : UIViewController


@property(nonatomic,retain)UIView *view1;
@property(nonatomic,retain)UISlider *red,*green,*blue;

@end
