//
//  ColorViewController.m
//  Slider
//
//  Created by Student on 28/11/16.
//  Copyright (c) 2016 Student. All rights reserved.
//

#import "ColorViewController.h"

@interface ColorViewController ()

@end

@implementation ColorViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    _view1=[[UIView alloc]initWithFrame:CGRectMake(50, 50, 250, 250)];
    _view1.backgroundColor=[UIColor blackColor];
    
    [self.view addSubview:_view1];
    
    _red=[[UISlider alloc]initWithFrame:CGRectMake(50,350,250,30)];
    _red.minimumValue=0;
    _red.maximumValue=255;
    
    _red.minimumTrackTintColor=[UIColor blackColor];
    _red.maximumTrackTintColor=[UIColor redColor];
    
    [_red addTarget:self action:@selector(sliderchange) forControlEvents:UIControlEventValueChanged];
    
    [self.view addSubview:_red];
    
    _green=[[UISlider alloc]initWithFrame:CGRectMake(50, 400, 250, 30)];
    _green.minimumValue=0;
    _green.maximumValue=255;
    
    _green.minimumTrackTintColor=[UIColor blackColor];
    _green.maximumTrackTintColor=[UIColor greenColor];
    
    [_green addTarget:self action:@selector(sliderchange) forControlEvents:UIControlEventValueChanged];
    [self.view addSubview:_green];
    
    _blue=[[UISlider alloc]initWithFrame:CGRectMake(50, 450, 250, 30)];
    _blue.minimumValue=0;
    _blue.maximumValue=255;
    
    _blue.minimumTrackTintColor=[UIColor blackColor];
    _blue.maximumTrackTintColor=[UIColor blueColor];
    
    [_blue addTarget:self action:@selector(sliderchange) forControlEvents:UIControlEventValueChanged];
    [self.view addSubview:_blue];
    
}

-(void)sliderchange
{
    _view1.backgroundColor=[UIColor colorWithRed:_red.value/255 green:_green.value/255 blue:_blue.value/255 alpha:1.0];

}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
