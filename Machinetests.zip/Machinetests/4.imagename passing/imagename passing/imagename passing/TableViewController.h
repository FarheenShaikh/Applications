//
//  TableViewController.h
//  imagename passing
//
//  Created by Student on 29/11/16.
//  Copyright (c) 2016 Student. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableViewController : UITableViewController


@property(nonatomic,retain)NSMutableArray *imgarray;
@end
