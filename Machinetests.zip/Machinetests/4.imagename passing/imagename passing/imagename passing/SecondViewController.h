//
//  SecondViewController.h
//  imagename passing
//
//  Created by Student on 29/11/16.
//  Copyright (c) 2016 Student. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SecondViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIImageView *imgview;

@property(nonatomic,retain)NSString *tempimgname;
@end
