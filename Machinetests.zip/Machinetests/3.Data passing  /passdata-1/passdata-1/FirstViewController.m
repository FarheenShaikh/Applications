//
//  FirstViewController.m
//  passdata-1
//
//  Created by Student on 24/11/16.
//  Copyright (c) 2016 Student. All rights reserved.
//

#import "FirstViewController.h"
#import "SecondViewController.h"

@interface FirstViewController ()

@end

@implementation FirstViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

//- (IBAction)passdatatoVC:(id)sender {
//    SecondViewController *svc=[[SecondViewController alloc]init];
//    svc.tempstring=_tf.text;
//    
//    [self.navigationController pushViewController:svc animated:YES
//     ];
//    
//    
//}
- (IBAction)savebtnclick:(id)sender {
    
    _dict=[[NSMutableDictionary alloc]init];
    [_dict setValue:_tf.text forKey:@"empid"];
    [_dict setValue:_tf1.text forKey:@"name"];
    
    
    if(_segment.selectedSegmentIndex==0)
        [_dict setValue:_imgview1.image forKey:@"imageview"];
    else if(_segment.selectedSegmentIndex==1)
        [_dict setValue:_imgview2.image forKey:@"imageview"];
    else
        [_dict setValue:_imgview3.image forKey:@"imageview"];


    
  //  [dict setValue: forKey:<#(NSString *)#>]

}

- (IBAction)passbtnclick:(id)sender {
   SecondViewController *svc=[[SecondViewController alloc]init];
    
    svc.tempdict=_dict;
    
    
    
    [self.navigationController pushViewController:svc animated:YES];
    
}

- (IBAction)segchange:(id)sender {
//    if(_segment.selectedSegmentIndex==0)
//    _imgview1.image=[UIImage imageNamed:@"Australia"];
//    else if(_segment.selectedSegmentIndex==1)
//        _imgview2.image=[UIImage imageNamed:@"Brazil"];
//    else
//        _imgview3.image=[UIImage imageNamed:@"Austria"];
    
        
    
}
@end
