//
//  FirstViewController.h
//  passdata-1
//
//  Created by Student on 24/11/16.
//  Copyright (c) 2016 Student. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FirstViewController : UIViewController

@property(nonatomic,retain)NSMutableDictionary *dict;
@property (weak, nonatomic) IBOutlet UITextField *tf;
@property (weak, nonatomic) IBOutlet UISegmentedControl *segment;
@property (weak, nonatomic) IBOutlet UITextField *tf1;


@property (weak, nonatomic) IBOutlet UIImageView *imgview1;

@property (weak, nonatomic) IBOutlet UIImageView *imgview2;
@property (weak, nonatomic) IBOutlet UIImageView *imgview3;

@property (weak, nonatomic) IBOutlet UIButton *savebtn;
@property (weak, nonatomic) IBOutlet UIButton *passbtn;

- (IBAction)savebtnclick:(id)sender;
- (IBAction)passbtnclick:(id)sender;

- (IBAction)segchange:(id)sender;

//- (IBAction)passdatatoVC:(id)sender;

@end
