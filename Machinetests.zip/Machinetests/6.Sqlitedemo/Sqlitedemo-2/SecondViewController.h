//
//  SecondViewController.h
//  Sqlitedemo-2
//
//  Created by Student on 02/12/16.
//  Copyright (c) 2016 Student. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SecondViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITextField *rollnotf;

@property (weak, nonatomic) IBOutlet UITextField *nametf;
@property (weak, nonatomic) IBOutlet UITextField *addresstf;
@property (weak, nonatomic) IBOutlet UITextField *phonenotf;
@property(nonatomic,retain)NSMutableArray *temparray;
- (IBAction)savebtnclick:(id)sender;

@end
