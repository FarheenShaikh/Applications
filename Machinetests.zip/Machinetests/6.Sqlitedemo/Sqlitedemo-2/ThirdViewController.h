//
//  ThirdViewController.h
//  Sqlitedemo-2
//
//  Created by Student on 02/12/16.
//  Copyright (c) 2016 Student. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ThirdViewController : UIViewController


@property (weak, nonatomic) IBOutlet UITextField *findtf;


@property (weak, nonatomic) IBOutlet UITextField *tf1;

@property (weak, nonatomic) IBOutlet UITextField *tf2;


@property (weak, nonatomic) IBOutlet UITextField *tf3;

- (IBAction)findbtnclick:(id)sender;
@property(nonatomic,retain)UIAlertView *alert;

@property (weak, nonatomic) IBOutlet UIButton *updatebtnclick;
- (IBAction)updateclick:(id)sender;




- (IBAction)deleteclick:(id)sender;


@end
