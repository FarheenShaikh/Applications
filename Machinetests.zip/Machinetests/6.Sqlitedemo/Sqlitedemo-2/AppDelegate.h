//
//  AppDelegate.h
//  Sqlitedemo-2
//
//  Created by Student on 02/12/16.
//  Copyright (c) 2016 Student. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

-(void)createdb;
@end

