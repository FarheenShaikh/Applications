//
//  ThirdViewController.m
//  Sqlitedemo-2
//
//  Created by Student on 02/12/16.
//  Copyright (c) 2016 Student. All rights reserved.
//

#import "ThirdViewController.h"
#import <sqlite3.h>

@interface ThirdViewController ()

@end

@implementation ThirdViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)findbtnclick:(id)sender {
    
    NSArray *dircontents=NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    
    NSString *dbpath=[NSString stringWithFormat:@"%@/Studentdatabase.sqlite",[dircontents lastObject]];
    
    sqlite3 *db;
    
    sqlite3_stmt *mystmt;
    
    if(sqlite3_open([dbpath UTF8String], &db)==SQLITE_OK)
    {
        
        NSString *findquery=[NSString stringWithFormat:@"select * from student where studrollno=\"%i\"",[_findtf.text intValue]];
        
        const char *que=[findquery UTF8String];
        
        if(sqlite3_prepare(db, que, -1, &mystmt, NULL)==SQLITE_OK)
        {
            if(sqlite3_step(mystmt)==SQLITE_ROW)
            {
               // int t1=sqlite3_column_int(mystmt, 0);
                NSString *t2=[NSString stringWithFormat:@"%s",sqlite3_column_text(mystmt, 1)];
                NSString *t3=[NSString stringWithFormat:@"%s",sqlite3_column_text(mystmt, 2)];
                int t4=sqlite3_column_int(mystmt, 3);
                
                _tf1.text=t2;
                _tf2.text=t3;
                _tf3.text=[NSString stringWithFormat:@"%i",t4];
                
            }
            else{
                
               // NSLog(@"no record");
                _alert=[[UIAlertView alloc]initWithTitle:@"Alert" message:@"Record not found" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Ok", nil ];
                [_alert show];
                
            }
            
            
        }
        else
        {
            NSLog(@"Failed to read record");

        }
        
        
    }
    else
    {
        NSLog(@"Failed to open database");
    }
    
    

    
    sqlite3_close(db);
    
    
}
- (IBAction)updateclick:(id)sender {
    NSArray *dircontents=NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *dbpath=[NSString stringWithFormat:@"%@/Studentdatabase.sqlite",[dircontents lastObject]];

    
    
   // sqlite3_stmt *mystmt;
    sqlite3 *db;
    if(sqlite3_open([dbpath UTF8String], &db)==SQLITE_OK)
    {
        NSString *updatequery=[NSString stringWithFormat:@"update student set studname=\"%@\",studadd=\"%@\",studphoneno=\"%i\" where studrollno=\"%i\"",_tf1.text,_tf2.text,[_tf3.text intValue],[_findtf.text intValue]];
        
        NSLog(@"%@",updatequery);
        
        const char *update_stmt = [updatequery UTF8String];
        
     
    if(sqlite3_exec(db, update_stmt, NULL, NULL, NULL)==SQLITE_OK)
        {
                      NSLog(@"record updated  successfully");
            
    }
           else
          {
            NSLog(@"Failed to update record");
            
          }
        
       
    }
    else
    {
        NSLog(@"failed to open database");
    }
    
        sqlite3_close(db);
    
}


- (IBAction)deleteclick:(id)sender {
    
    NSArray *dircontents=NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *dbpath=[NSString stringWithFormat:@"%@/Studentdatabase.sqlite",[dircontents lastObject]];
    
    
    
    sqlite3 *db;
    if(sqlite3_open([dbpath UTF8String], &db)==SQLITE_OK)
    {
        NSString *deletequery=[NSString stringWithFormat:@"delete from student where studrollno=\"%i\"",[_findtf.text intValue]];
        
        const char *delete_stmt = [deletequery UTF8String];
        
        
        if(sqlite3_exec(db, delete_stmt, NULL, NULL, NULL)==SQLITE_OK)
        {
            NSLog(@"record deleted  successfully");
            
        }
        else
        {
            NSLog(@"Failed to delete record");
            
        }
    }
    
    else
    {
        NSLog(@"failed to open database");
    }
    
    
    sqlite3_close(db);
    
}
@end
