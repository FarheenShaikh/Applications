//
//  FirstTableViewController.h
//  Sqlitedemo-2
//
//  Created by Student on 02/12/16.
//  Copyright (c) 2016 Student. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FirstTableViewController : UITableViewController


@property(nonatomic,retain)NSMutableArray *namearray;
@property(nonatomic,retain)NSString *tempnamestring;
@property(nonatomic,retain)UIRefreshControl *refresh;
@end
