//
//  FirstTableViewController.m
//  Sqlitedemo-2
//
//  Created by Student on 02/12/16.
//  Copyright (c) 2016 Student. All rights reserved.
//

#import "FirstTableViewController.h"
#import "SecondViewController.h"
#import "ThirdViewController.h"
#import <sqlite3.h>

@interface FirstTableViewController ()

@end

@implementation FirstTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   // [self.tableView reloadData];
    
    _namearray=[[NSMutableArray alloc]init];
    
    //[_namearray addObject:_tempnamestring];
    
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"cell"];
    
    

    _refresh=[[UIRefreshControl alloc]init];
    [_refresh addTarget:self action:@selector(ref) forControlEvents:UIControlEventAllEvents];
    [self.view addSubview:_refresh];
    
    
}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [_namearray removeAllObjects];
    
    NSArray *dircontents=NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    
    NSString *dbpath=[NSString stringWithFormat:@"%@/Studentdatabase.sqlite",[dircontents lastObject]];
    
    sqlite3 *db;
    sqlite3_stmt *mystmt;
    
    if(sqlite3_open([dbpath UTF8String], &db)==SQLITE_OK)
    {
        NSString *readquery=[NSString stringWithFormat:@"select * from student"];
        const char *que=[readquery UTF8String];
        
        if(sqlite3_prepare(db, que, -1, &mystmt, NULL)==SQLITE_OK)
        {
            while(sqlite3_step(mystmt)==SQLITE_ROW)
            {
                
                NSString *t2=[NSString stringWithFormat:@"%s",sqlite3_column_text(mystmt, 1)];
                
                [_namearray addObject:t2];
                
            }

         [self.tableView reloadData];
            
         }
        else
        {
            NSLog(@"Failed to read record");
        }
        
    }
    else
    {
        NSLog(@"Failed to open database");
    }
    
    sqlite3_close(db);
    [self.tableView reloadData];
    
    
    
}
-(void)ref
{
    [_refresh beginRefreshing];
    [self.tableView reloadData];
    [_refresh endRefreshing];
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    return _namearray.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    
    // Configure the cell...
    
    
    cell.textLabel.text=[_namearray objectAtIndex:indexPath.row];
    return cell;
}


/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if([[segue identifier]isEqualToString:@"fvctosvc"])
    {
        SecondViewController *svc=[segue destinationViewController];
        svc.temparray=_namearray;
        
        
    
    }
    else if([[segue identifier]isEqualToString:@"svctotvc"])
    {
        ThirdViewController *tvc=[segue destinationViewController];
    
    }
}


@end
