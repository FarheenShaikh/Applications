//
//  SecondViewController.m
//  Sqlitedemo-2
//
//  Created by Student on 02/12/16.
//  Copyright (c) 2016 Student. All rights reserved.
//

#import "SecondViewController.h"
#import "FirstTableViewController.h"
#import <sqlite3.h>

@interface SecondViewController ()

@end

@implementation SecondViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)savebtnclick:(id)sender {
    
    NSArray *dircontents=NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *dbpath=[NSString stringWithFormat:@"%@/Studentdatabase.sqlite",[dircontents lastObject]];
    
    
    
    sqlite3 *db;
    if(sqlite3_open([dbpath UTF8String], &db)==SQLITE_OK)
    {
    NSString *insertquery=[NSString stringWithFormat:@"insert into student(studrollno,studname,studadd,studphoneno)values(\"%i\",\"%@\",\"%@\",\"%i\");",[_rollnotf.text intValue],_nametf.text,_addresstf.text,[_phonenotf.text intValue]];
        
        const char *insert_stmt = [insertquery UTF8String];
        
                           
        if(sqlite3_exec(db, insert_stmt, NULL, NULL, NULL)==SQLITE_OK)
        {
            NSLog(@"record inserted  successfully");
           
            [_temparray addObject:_nametf.text];
            [self.navigationController popViewControllerAnimated:YES];
            
            
        }
        else
        {
            NSLog(@"Failed to insert record");
            
        }
    }
    
    else
    {
        NSLog(@"failed to open database");
    }
    
    
    sqlite3_close(db);
    
    
}
@end
