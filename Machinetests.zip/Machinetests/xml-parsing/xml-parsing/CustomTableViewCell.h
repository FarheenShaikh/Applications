//
//  CustomTableViewCell.h
//  xml-parsing
//
//  Created by Student on 14/12/16.
//  Copyright (c) 2016 Student. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *commonlbl;
@property (weak, nonatomic) IBOutlet UILabel *botanicallbl;

@property (weak, nonatomic) IBOutlet UILabel *zonelbl;

@property (weak, nonatomic) IBOutlet UILabel *pricelbl;

@property (weak, nonatomic) IBOutlet UILabel *lightlbl;

@property (weak, nonatomic) IBOutlet UILabel *availabllbl;

@end
