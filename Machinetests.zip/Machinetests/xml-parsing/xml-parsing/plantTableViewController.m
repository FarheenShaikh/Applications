//
//  plantTableViewController.m
//  xml-parsing
//
//  Created by Student on 14/12/16.
//  Copyright (c) 2016 Student. All rights reserved.
//

#import "plantTableViewController.h"
#import "Plant.h"
#import "CustomTableViewCell.h"

@interface plantTableViewController ()

@end

@implementation plantTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
//    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"cell"];
    [self.tableView registerNib:[UINib nibWithNibName:@"CustomTableViewCell" bundle:[NSBundle mainBundle]]forCellReuseIdentifier:@"cell"];
    
    _plantarray=[[NSMutableArray alloc]init];
    
//NSString *str=@"http://www.w3schools.com/xml/plant_catalogxml";
   // _saxparser=[[NSXMLParser alloc]initWithContentsOfURL:[NSURL URLWithString:str]];
    NSURL *filepath=[[NSBundle mainBundle]URLForResource:@"plant_catalogue" withExtension:@"xml"];
    
    
    _saxparser=[[NSXMLParser alloc]initWithContentsOfURL:filepath];
    _saxparser.delegate=self;
    [_saxparser parse];
    
    
}
-(void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict
{
    
    if([elementName isEqualToString:@"PLANT"])
    {
        _p=[[Plant alloc]init];
    }
    if([elementName isEqualToString:@"COMMON"] )
    {
        _commonstring=[[NSMutableString alloc]init];
    
    }
    if([elementName isEqualToString:@"BOTANICAL"] )
    {
        _commonstring=[[NSMutableString alloc]init];
        
    }

    if([elementName isEqualToString:@"ZONE"] )
    {
        _commonstring=[[NSMutableString alloc]init];
        
    }
    if([elementName isEqualToString:@"LIGHT"] )
    {
        _commonstring=[[NSMutableString alloc]init];
        
    }
    if([elementName isEqualToString:@"PRICE"] )
    {
        _commonstring=[[NSMutableString alloc]init];
        
    }
    if([elementName isEqualToString:@"AVAILABILITY"] )
    {
        _commonstring=[[NSMutableString alloc]init];
        
    }


}

-(void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
    [_commonstring appendString:string];

}
-(void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName
{
  if([elementName isEqualToString:@"COMMON"])
  {
      _p.common=_commonstring;
  }
  if([elementName isEqualToString:@"BOTANICAL"])
  {
        _p.botanical=_commonstring;
  }
  if([elementName isEqualToString:@"ZONE"])
  {
        _p.zone=_commonstring;
  }
    if([elementName isEqualToString:@"LIGHT"])
    {
        _p.light=_commonstring;
    }
    if([elementName isEqualToString:@"PRICE"])
    {
        _p.price=_commonstring;
    }
    if([elementName isEqualToString:@"AVAILABILITY"])
    {
        _p.availability=_commonstring;
    }
    if([elementName isEqualToString:@"PLANT"])
    {
        [_plantarray addObject:_p];
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
//#warning Potentially incomplete method implementation.
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
//#warning Incomplete method implementation.
    // Return the number of rows in the section.
    return _plantarray.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    CustomTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    
    // Configure the cell...

    Plant *temp=[_plantarray objectAtIndex:indexPath.row];
    cell.commonlbl.text=temp.common;
    cell.botanicallbl.text=temp.botanical;
    cell.zonelbl.text=temp.zone;
    cell.lightlbl.text=temp.light;
    cell.pricelbl.text=temp.price;
    cell.availabllbl.text=temp.availability;
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 130;
}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
