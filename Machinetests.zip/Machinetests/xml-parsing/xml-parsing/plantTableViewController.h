//
//  plantTableViewController.h
//  xml-parsing
//
//  Created by Student on 14/12/16.
//  Copyright (c) 2016 Student. All rights reserved.
//

#import <UIKit/UIKit.h>
#include "Plant.h"

@interface plantTableViewController : UITableViewController<NSXMLParserDelegate>

@property(nonatomic,retain)NSMutableArray *plantarray;
@property(nonatomic,retain)NSMutableString *commonstring;
@property(nonatomic,retain)NSXMLParser *saxparser;
@property(nonatomic,retain)Plant *p;
@end
