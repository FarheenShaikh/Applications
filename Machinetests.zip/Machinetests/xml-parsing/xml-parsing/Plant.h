//
//  Plant.h
//  xml-parsing
//
//  Created by Student on 14/12/16.
//  Copyright (c) 2016 Student. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Plant : NSObject

@property(nonatomic,retain)NSString *common,*botanical,*zone,*light,*price,*availability;

@end
