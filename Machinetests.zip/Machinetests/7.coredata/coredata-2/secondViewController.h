//
//  secondViewController.h
//  coredata-2
//
//  Created by Student on 07/12/16.
//  Copyright (c) 2016 Student. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface secondViewController : UIViewController


@property (weak, nonatomic) IBOutlet UITextField *rnotf;

@property (weak, nonatomic) IBOutlet UITextField *nametf;

@property (weak, nonatomic) IBOutlet UITextField *addresstf;
@property (weak, nonatomic) IBOutlet UITextField *phonenotf;

- (IBAction)savebtnclick:(id)sender;

@property(nonatomic,retain)NSMutableArray *temparray;

@end
