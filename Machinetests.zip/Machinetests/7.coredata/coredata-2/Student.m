//
//  Student.m
//  coredata-2
//
//  Created by Student on 07/12/16.
//  Copyright (c) 2016 Student. All rights reserved.
//

#import "Student.h"


@implementation Student

@dynamic rollno;
@dynamic name;
@dynamic address;
@dynamic phoneno;

@end
