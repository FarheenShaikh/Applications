//
//  ThirdViewController.h
//  coredata-2
//
//  Created by Student on 07/12/16.
//  Copyright (c) 2016 Student. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ThirdViewController : UIViewController
- (IBAction)findbtnclick:(id)sender;
@property (weak, nonatomic) IBOutlet UITextField *findtf;
@property (weak, nonatomic) IBOutlet UITextField *nametf;
@property (weak, nonatomic) IBOutlet UITextField *addresstf;
@property (weak, nonatomic) IBOutlet UITextField *phonenotf;

- (IBAction)updatebtnclick:(id)sender;

- (IBAction)deletebtnclick:(id)sender;

@property(nonatomic,retain)UIAlertView *alert;
@end
