//
//  secondViewController.m
//  coredata-2
//
//  Created by Student on 07/12/16.
//  Copyright (c) 2016 Student. All rights reserved.
//

#import "secondViewController.h"
#import "AppDelegate.h"
#import "Student.h"

@interface secondViewController ()

@end

@implementation secondViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)savebtnclick:(id)sender {
    
    UIApplication *myapplication=[UIApplication sharedApplication];
    
    AppDelegate *mydelegate=(AppDelegate *)myapplication.delegate;
    
    NSManagedObjectContext *context=mydelegate.managedObjectContext;
    
    Student *s1=[NSEntityDescription insertNewObjectForEntityForName:@"Student" inManagedObjectContext:context];
    
    s1.rollno=[NSNumber numberWithInt:[_rnotf.text intValue]];
    
    s1.name=_nametf.text;
    s1.address=_addresstf.text;
    s1.phoneno=[NSNumber numberWithInt:[_phonenotf.text intValue]];
                
    [context save:nil];
    
    [_temparray addObject:_nametf.text];
    [self.navigationController popViewControllerAnimated:YES];
    
    
    
    
    
    
    
    
    
}
@end
