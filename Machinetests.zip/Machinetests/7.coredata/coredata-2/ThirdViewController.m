//
//  ThirdViewController.m
//  coredata-2
//
//  Created by Student on 07/12/16.
//  Copyright (c) 2016 Student. All rights reserved.
//

#import "ThirdViewController.h"
#import "AppDelegate.h"
#import "Student.h"

@interface ThirdViewController ()

@end

@implementation ThirdViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)findbtnclick:(id)sender {
    
    UIApplication *myapplication=[UIApplication sharedApplication];
    AppDelegate *mydelegate=(AppDelegate *)myapplication.delegate;
    NSManagedObjectContext *context=mydelegate.managedObjectContext;
    
    NSFetchRequest *request=[NSFetchRequest fetchRequestWithEntityName:@"Student"];
    
    NSArray *result=[context executeFetchRequest:request error:nil];
    
    for(Student *temp in result)
    {
        
        if([temp.rollno isEqualToNumber:[NSNumber numberWithInt:[_findtf.text intValue]]])
                                                                 
        {
        _nametf.text=temp.name;
        _addresstf.text=temp.address;
        _phonenotf.text=[NSString stringWithFormat:@"%i",[temp.phoneno intValue]];
        NSLog(@"%i  %@  %@  %@",[temp.rollno intValue],temp.name,temp.address,temp.phoneno);
        }
        else
        {
            _alert=[[UIAlertView alloc]initWithTitle:@"Alert" message:@"Record not found" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Ok", nil ];
            [_alert show];

        }
        
    }
    
    

}
- (IBAction)updatebtnclick:(id)sender {
    
    UIApplication *myapplication=[UIApplication sharedApplication];
    AppDelegate *mydelegate=(AppDelegate *)myapplication.delegate;
    NSManagedObjectContext *context=mydelegate.managedObjectContext;
    
    NSFetchRequest *request=[NSFetchRequest fetchRequestWithEntityName:@"Student"];
    

    NSPredicate *predicate=[NSPredicate predicateWithFormat:@"rollno==%i",[_findtf.text intValue]];
    
   // [request setPredicate:predicate];
    
     NSArray *result=[context executeFetchRequest:request error:nil];

   NSArray *r= [result filteredArrayUsingPredicate:predicate];
    
    Student *s =[r objectAtIndex:0];
        s.name=_nametf.text;
        
        s.address=_addresstf.text;
        s.phoneno=[NSNumber numberWithInt:[_phonenotf.text intValue]];

        [context save:nil];
        NSLog(@"%i  %@  %@  %@",[s.rollno intValue],s.name,s.address,s.phoneno);
        
        
    
    
}

- (IBAction)deletebtnclick:(id)sender {
    
    UIApplication *myapplication=[UIApplication sharedApplication];
    AppDelegate *mydelegate=(AppDelegate *)myapplication.delegate;
    NSManagedObjectContext *context=mydelegate.managedObjectContext;
    
    NSFetchRequest *request=[NSFetchRequest fetchRequestWithEntityName:@"Student"];
    
    
    NSPredicate *predicate=[NSPredicate predicateWithFormat:@"rollno==%i",[_findtf.text intValue]];
    
    // [request setPredicate:predicate];
    
    NSArray *result=[context executeFetchRequest:request error:nil];
    
    NSArray *r= [result filteredArrayUsingPredicate:predicate];
    
    Student *s =[r objectAtIndex:0];
    
   // NSManagedObject *objecttobedelete=[r objectAtIndex:0];
    
    [context deleteObject:s];

//    s.name=nil;
//    
//    s.address=nil;
//    s.phoneno=nil;
//    
    [context save:nil];
   // NSLog(@"%i  %@  %@  %@",[s.rollno intValue],s.name,s.address,s.phoneno);
    
    
    
}
@end
